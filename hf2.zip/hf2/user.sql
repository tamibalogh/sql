SELECT * FROM Ugyfel

CREATE user felhasznalo without login
grant SELECT on Ugyfel to felhasznalo
execute as user = 'felhasznalo'
SELECT * from Ugyfel

revert
SELECT * FROM Ugyfel